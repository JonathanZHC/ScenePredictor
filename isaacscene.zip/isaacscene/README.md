# IsaacScene

A lightweight Isaac Sim scene and ROS 2 RGB-D publisher for multi-view perception, tracking, and scene-flow experiments.

The repository builds deterministic tabletop scenes, renders two calibrated RGB-D cameras, and publishes the resulting sensor streams through ROS 2. It is intended to be usable as a standalone simulation source for downstream perception systems such as multi-view RGB-D tracking and scene-flow pipelines.

## Features

- Two calibrated RGB-D cameras with fixed world-frame poses.
- RGB, metric depth (`32FC1`), `CameraInfo`, camera pose, and per-camera `PointCloud2` output.
- Four scene modes: `static`, `dynamic`, `hybrid`, and `occlusion`.
- Scripted moving objects for repeatable dynamic-scene experiments.
- Deterministic clear/partial/full occlusion benchmark.
- Optional GPU RGB/depth corruption implemented with NVIDIA Warp.
- GPU point-cloud construction utilities.
- Camera-frustum visualization in Isaac Sim and ROS visualization markers.
- Built-in runtime timing/profiling statistics.

## Repository layout

```text
isaacscene/
├── run_isaacsim.py                 # Main Isaac Sim entry point
├── scene_settings.py               # Tabletop scene construction
├── moving_objects.py               # Scripted dynamic object motion
├── occlusion_scene.py              # Deterministic occlusion benchmark
├── isaac_asset_objects.py          # Isaac asset lookup/loading/placement
├── camera_settings.py              # Camera calibration and RGB-D capture
├── camera_corruption_warp.py       # GPU RGB/depth corruption
├── ros_camera_publisher.py         # ROS 2 publishers and static TF
├── pointcloud_full_gpu.py          # Full per-camera point-cloud generation
├── pointcloud_debug_gpu.py         # GPU merged/debug point-cloud utilities
├── camera_pyramid_visualizer.py    # Isaac Sim camera-frustum visualization
├── isaacsim_visualizer.py          # Additional Isaac Sim GUI visualization
├── isaacscene.rviz                 # RViz configuration
├── python_image_rate_subscriber.py # ROS image-rate diagnostic tool
├── verify_scene_assets.py          # Isaac asset availability check
├── verify_occlusion_geometry.py    # Pure-Python occlusion geometry check
├── test_gpu_pointcloud.py          # GPU point-cloud sanity test
└── test_warp_corruption.py         # Warp corruption sanity test
```

## Requirements

This repository is intended to run inside an NVIDIA Isaac Sim Python environment with:

- NVIDIA Isaac Sim
- NVIDIA GPU with CUDA support
- NVIDIA Warp
- ROS 2 with `rclpy`
- ROS 2 message packages used by `sensor_msgs`, `geometry_msgs`, `visualization_msgs`, and TF2

The main process sets:

```text
ROS_DOMAIN_ID=117
RMW_IMPLEMENTATION=rmw_fastrtps_cpp
```

Any external ROS 2 consumer, such as RViz or a tracking pipeline, should use the same ROS domain:

```bash
export ROS_DOMAIN_ID=117
```

## Quick start

Run the default static scene at 640x480 and 30 Hz RGB-D:

```bash
cd isaacscene
/isaac-sim/python.sh run_isaacsim.py --scene static
```

If your shell is already using the Isaac Sim Python environment, the executable entry point can also be used directly:

```bash
./run_isaacsim.py --scene static
```

The default configuration publishes RGB-D at 30 Hz and full per-camera point clouds at 2 Hz.

### Headless mode

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene static \
  --headless
```

### Disable PointCloud2 generation

If the downstream pipeline only needs RGB-D images and camera calibration, disable the full point-cloud publisher:

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene static \
  --rgbd-hz 30 \
  --pointcloud-hz 0
```

This avoids the additional full point-cloud generation and ROS publication work.

## Scene modes

Select the complete scene configuration with `--scene`.

| Mode | Description |
|---|---|
| `static` | Shelf, ball, and six daily/YCB-style objects remain stationary. |
| `dynamic` | Moving shelf, bouncing/translating ball, bottle, food can, and mug. |
| `hybrid` | Four stationary daily objects together with the moving shelf and ball. |
| `occlusion` | Static rear objects plus the same moving ball trajectory and a deterministic foreground occlusion panel. |

### Dynamic scene

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene dynamic \
  --rgbd-hz 30
```

All scripted trajectory speeds can be scaled together:

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene dynamic \
  --motion-speed-scale 1.5
```

### Hybrid scene

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene hybrid
```

### Occlusion benchmark

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene occlusion \
  --rgbd-hz 30 \
  --pointcloud-hz 0
```

The foreground panel repeatedly produces the visibility sequence:

```text
clear -> partial -> full -> partial -> clear
```

The panel is a test fixture rather than a semantic target. Runtime logs report phase transitions as:

```text
[OCCLUSION] state=clear|partial|full
```

The moving ball uses the same underlying motion profile as in the dynamic scene. `--motion-speed-scale` scales both object and panel motion.

## Camera corruption

Optional camera corruption is performed on the GPU using NVIDIA Warp.

Enable RGB and depth corruption:

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene dynamic \
  --corrupt
```

Keep RGB clean while corrupting depth:

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene dynamic \
  --corrupt \
  --no-rgb-corruption
```

Keep depth clean while corrupting RGB:

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene dynamic \
  --corrupt \
  --no-depth-corruption
```

## ROS 2 interface

Each camera publishes an independent RGB-D stream.

### Camera 0

```text
/camera_0/color/image_raw
/camera_0/depth/image_raw
/camera_0/camera_info
/camera_0/pose
/camera_0/points
```

### Camera 1

```text
/camera_1/color/image_raw
/camera_1/depth/image_raw
/camera_1/camera_info
/camera_1/pose
/camera_1/points
```

### Visualization

```text
/cameras/visualization
```

The image streams use RGB8 and metric `32FC1` depth. Per-camera point clouds contain valid XYZRGB points in the corresponding camera optical frame and are not fused or downsampled by `run_isaacsim.py`.

The current publisher does **not** publish `/cameras/fused_points`; downstream multi-view fusion is intentionally left to the perception/tracking pipeline.

## TF frames

The simulator publishes static transforms:

```text
world -> camera_0_optical_frame
world -> camera_1_optical_frame
```

The optical frames follow the ROS/OpenCV convention:

```text
+x : right
+y : down
+z : forward
```

## RViz

Use the same ROS domain as the simulator:

```bash
export ROS_DOMAIN_ID=117
rviz2 -d isaacscene.rviz
```

The included RViz configuration contains displays for the camera streams and visualization markers. Note that older configurations may also contain a legacy `/cameras/fused_points` display; the current simulator intentionally publishes only the independent per-camera point clouds.

## Useful command-line options

```text
--width N
--height N
--rgbd-hz HZ
--pointcloud-hz HZ
--headless
--corrupt
--no-rgb-corruption
--no-depth-corruption
--scene {static,dynamic,hybrid,occlusion}
--motion-speed-scale SCALE
--shelf-usd PATH_OR_URL
--ball-usd PATH_OR_URL
--profile-every N
```

For the complete current interface:

```bash
/isaac-sim/python.sh run_isaacsim.py --help
```

## Performance profiling

After renderer warm-up, `run_isaacsim.py` periodically reports timing statistics for:

```text
capture_ms
ros_ms
pointcloud_ms
pipeline_ms
actual_period_ms
achieved_hz
```

Control the reporting interval with:

```bash
--profile-every N
```

For example:

```bash
/isaac-sim/python.sh run_isaacsim.py \
  --scene dynamic \
  --rgbd-hz 30 \
  --pointcloud-hz 0 \
  --profile-every 120
```

## Diagnostics and verification

### Verify Isaac assets

```bash
/isaac-sim/python.sh verify_scene_assets.py
```

Optional custom shelf/ball USD assets can be supplied with:

```bash
/isaac-sim/python.sh verify_scene_assets.py \
  --shelf-usd /path/to/shelf.usd \
  --ball-usd /path/to/ball.usd
```

The same overrides are accepted by `run_isaacsim.py`.

### Verify occlusion geometry

This check is pure Python and does not start Isaac Sim:

```bash
python3 verify_occlusion_geometry.py
```

### Check ROS image receive rate

In a ROS 2 environment:

```bash
export ROS_DOMAIN_ID=117
python3 python_image_rate_subscriber.py \
  --topic /camera_0/depth/image_raw \
  --expected-hz 30
```

### GPU sanity checks

```bash
/isaac-sim/python.sh test_warp_corruption.py
/isaac-sim/python.sh test_gpu_pointcloud.py
```

## Intended downstream use

`isaacscene` deliberately stops at calibrated multi-camera RGB-D sensing and ROS publication. Cross-view instance association, temporal tracking, scene flow, and velocity estimation belong in downstream repositories.

A typical pipeline is:

```text
IsaacScene
   |
   |  dual-camera RGB-D + calibration + TF
   v
Multi-view RGB-D tracking
   |
   |  fused, temporally aligned instances
   v
Scene flow / velocity estimation
```

Keeping this simulator independent makes the scene and sensor source reusable for testing different perception pipelines without coupling them to the simulation implementation.
